﻿namespace AgendaVeterinaria1.Controllers
{
    public class AuthorizationContext
    {
    }
}